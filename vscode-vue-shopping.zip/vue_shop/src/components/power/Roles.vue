<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>权限管理</el-breadcrumb-item>
      <el-breadcrumb-item>角色列表</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 卡片视图区域 -->
    <el-card class="box-card">
      <el-row>
        <el-col>
          <el-button type="primary" @click="addDialogVisible=true">添加角色</el-button>
        </el-col>
      </el-row>
      <el-table :data="rolesList" border stripe>
        <!-- 展开列 -->
        <el-table-column type="expand">
          <template v-slot="{row}">
            <el-row :class="['bd-bottom','vcenter',i1===0?'bd-top':'']" v-for="(item1,i1) in row.children" :key="item1.id">
              <!-- 渲染一级权限 -->
              <el-col :span="5">
                <el-tag closable @close="removeRightById(row,item1.id)">{{item1.authName}}</el-tag>
                <i class="el-icon-caret-right"></i>
              </el-col>
              <!-- 渲染二级权限和三级权限 -->
              <el-col :span="19">
                <el-row :class="[i2===0?'':'bd-top','vcenter']" v-for="(item2,i2) in item1.children" :key="item2.id">
                  <!-- 渲染二级权限 -->
                  <el-col :span="6">
                    <el-tag type="success" closable @close="removeRightById(row,item2.id)">
                      {{item2.authName}}
                    </el-tag>
                    <i class="el-icon-caret-right"></i>
                  </el-col>
                  <!-- 渲染三级权限 -->
                  <el-col :span="18">
                    <el-tag type="warning" v-for="item3 in item2.children" :key="item3.id" closable @close="removeRightById(row,item3.id)">
                      {{item3.authName}}
                    </el-tag>
                  </el-col>
                </el-row>
              </el-col>
            </el-row>
          </template>
        </el-table-column>
        <!-- 索引列 -->
        <el-table-column type="index" label="#"></el-table-column>
        <!-- 内容列 -->
        <el-table-column label="角色名称" prop="roleName"></el-table-column>
        <el-table-column label="角色描述" prop="roleDesc"></el-table-column>
        <el-table-column label="操作">
          <template v-slot="{row}">
            <el-button type="primary" icon="el-icon-edit" size="mini" @click="showEditDialog(row.id)">编辑</el-button>
            <el-button type="danger" icon="el-icon-delete" size="mini" @click="deleteRoleInfo(row.id)">删除</el-button>
            <el-button type="warning" icon="el-icon-setting" size="mini" @click="showSetRightDialog(row)">分配权限</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
    <!-- 添加角色对话框 -->
    <el-dialog title="添加角色" :visible.sync="addDialogVisible" width="50%" @close="addDialogClosed">
      <el-form :model="addForm" :rules="addFormRules" ref="addFormRef" label-width="80px" :status-icon="true">
        <!-- 角色名称输入框 -->
        <el-form-item label="角色名称" prop="roleName">
          <el-input v-model="addForm.roleName"></el-input>
        </el-form-item>
        <el-form-item label="角色描述">
          <el-input v-model="addForm.roleDesc"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="addDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="addRole">添 加</el-button>
      </span>
    </el-dialog>

    <!-- 编辑角色对话框 -->
    <el-dialog title="编辑角色" :visible.sync="editDialogVisible" width="50%" @close="editDialogClosed">
      <el-form :model="editForm" :rules="addFormRules" ref="editFormRef" label-width="80px" :status-icon="true">
        <!-- 角色名称输入框 -->
        <el-form-item label="角色名称" prop="roleName">
          <el-input v-model="editForm.roleName"></el-input>
        </el-form-item>
        <el-form-item label="角色描述">
          <el-input v-model="editForm.roleDesc"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="editDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="editRoleInfo">提 交</el-button>
      </span>
    </el-dialog>

    <!-- 分配权限的对话框 -->
    <el-dialog title="分配权限" :visible.sync="setRightDialogVisible" width="50%" @close="setRightDialogClosed">
      <!-- 树形控件区域 -->
      <el-tree :data="rightsList" :props="treeProps" show-checkbox node-key="id" default-expand-all :default-checked-keys="defKeys" ref="treeRef"></el-tree>
      <span slot="footer" class="dialog-footer">
        <el-button @click="setRightDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="allotRights">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
    data () {
        return {
            // 角色列表数据
            rolesList: [],
            // 添加角色数据
            addForm: {
                roleName: '',
                roleDesc: ''
            },
            // 编辑角色数据
            editForm: {},
            // 所有权限的数据
            rightsList: [],
            // 显示 / 隐藏 添加角色对话框
            addDialogVisible: false,
            // 显示 / 隐藏 编辑角色对话框
            editDialogVisible: false,
            // 显示 / 隐藏 分配权限对话框
            setRightDialogVisible: false,
            addFormRules: {
                // 角色名验证规则
                roleName: [
                    { required: true, message: '请输入角色名称', trigger: 'blur' },
                    { min: 2, max: 10, message: '长度在 2 到 10 个字符', trigger: 'blur' }
                ]
            },
            // 树形控件的属性绑定对象
            treeProps: {
                // 显示哪个文本内容 指定节点标签为节点对象的某个属性值
                label: 'authName',
                // 父子节点通过哪个属性进行嵌套 指定子树为节点对象的某个属性值
                children: 'children'
            },
            // 默认选中节点id值数组
            defKeys: [],
            // 当前即将分配权限的角色id
            roleId: ''
        }
    },
    created () {
    // 获取角色列表数据
        this.getRolesList()
    },
    methods: {
    // 获取角色列表数据
        async getRolesList () {
            // 向服务器发送请求 获取角色列表数据
            const res = await this.$http.get('roles')
            if (res.meta.status !== 200) {
                return this.$message.error('获取角色列表失败!')
            }
            this.rolesList = res.data
        },
        // 当添加角色对话框关闭时 触发函数
        addDialogClosed () {
            // 清除添加角色表单内容
            this.addForm.roleDesc = ''
            this.$refs.addFormRef.resetFields()
        },
        // 添加角色
        addRole () {
            // 提交时 再次验证格式是否正确
            this.$refs.addFormRef.validate(async valid => {
                // 如果验证未通过 并返回
                if (!valid) {
                    return this.$message.error('请输入正确的角色信息!')
                }
                // 验证通过 向服务器发送请求添加角色
                const res = await this.$http.post('roles', this.addForm)
                if (res.meta.status !== 201) {
                    return this.$message.error('角色创建失败!')
                }
                // 提示信息——角色创建成功
                this.$message.success('角色创建成功!')
                // 隐藏对话框
                this.addDialogVisible = false
                // 重新获取角色列表数据
                this.getRolesList()
            })
        },
        // 显示编辑角色信息的对话框
        async showEditDialog (id) {
            const res = await this.$http.get(`roles/${id}`)
            if (res.meta.status !== 200) {
                return this.$message.error('角色信息获取失败!')
            }
            // 将查询的结果 赋值给修改表单
            this.editForm = res.data
            this.editDialogVisible = true
        },
        // 当修改输入框关闭时触发
        editDialogClosed () {
            // 清除修改表单的内容和校验信息
            this.$refs.editFormRef.resetFields()
        },
        // 当点击了编辑表单的提交按钮触发
        editRoleInfo () {
            // 修改表单提交时的预验证
            this.$refs.editFormRef.validate(async valid => {
                if (!valid) {
                    return this.$message.error('请填写正确的角色信息!')
                }
                // 向服务器发送请求 修改角色信息
                const res = await this.$http.put(`roles/${this.editForm.roleId}`, {
                    roleName: this.editForm.roleName,
                    roleDesc: this.editForm.roleDesc
                })
                // 如果返回的状态码不为200 修改失败
                if (res.meta.status !== 200) {
                    return this.$message.error('角色信息修改失败!')
                }
                // 关闭修改对话框
                this.editDialogVisible = false
                // 重新请求角色列表数据
                this.getRolesList()
                // 提示信息 修改角色信息成功
                this.$message.success('角色信息修改成功!')
            })
        },
        // 当点击了表格的删除按钮触发
        deleteRoleInfo (id) {
            // 弹出确认提示框防止用户误触删除按钮
            this.$confirm('此操作将永久删除该角色信息, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(async () => {
                // 向服务器发送请求 删除用户信息
                const res = await this.$http.delete(`roles/${id}`)
                if (res.meta.status !== 200) {
                    return this.$message.error('角色信息删除失败！')
                }
                // 重新获取用户列表信息
                this.getRolesList()
                this.$message.success('角色信息删除成功!')
            }).catch(() => {
                this.$message.info('已取消删除!')
            })
        },
        // 当点击了权限的删除按钮 触发函数
        removeRightById (role, rightId) {
            // 弹出确认提示框防止用户误触删除按钮
            this.$confirm('此操作将永久删除该权限, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(async () => {
                // 向服务器发送请求 删除权限信息
                const res = await this.$http.delete(`roles/${role.id}/rights/${rightId}`)
                if (res.meta.status !== 200) {
                    return this.$message.error('权限删除失败！')
                }
                // 重新刷新权限列表信息
                role.children = res.data
                this.$message.success('权限删除成功!')
            }).catch(() => {
                this.$message.info('已取消删除!')
            })
        },
        // 当点击了分配权限按钮 触发函数
        async showSetRightDialog (role) {
            // 在data保存当前角色的id
            this.roleId = role.id
            // 获取所有权限的数据
            const res = await this.$http.get('rights/tree')
            if (res.meta.status !== 200) {
                return this.$message.error('权限列表获取失败!')
            }
            // 把获取出来的所有权限的数据保存在rightsList中
            this.rightsList = res.data
            // 递归获取三级节点的id
            this.getLeafId(role, this.defKeys)
            this.setRightDialogVisible = true
        },
        // 通过递归的形式,获取角色下三级权限的id,并保存到defKeys中
        getLeafId (node, arr) {
            // 如果当时的node节点不包含children属性说明该节点是三级节点
            if (!node.children) {
                return arr.push(node.id)
            }
            node.children.forEach(item => this.getLeafId(item, arr))
        },
        // 监听分配权限的对话框关闭事件
        setRightDialogClosed () {
            // 清空数组中的id数据
            this.defKeys = []
        },
        // 点击为角色分配权限
        async allotRights () {
            // 用数组存储选中和半选中的节点id值
            const keys = [...this.$refs.treeRef.getCheckedKeys(), ...this.$refs.treeRef.getHalfCheckedKeys()]
            // 将数组id转换为服务器要求的字符串id格式
            const rids = keys.join(',')
            // 向服务器发送请求 角色授权
            const res = await this.$http.post(`roles/${this.roleId}/rights`, { rids })
            if (res.meta.status !== 200) {
                // 提示错误信息并返回
                return this.$message.error('分配权限失败!')
            }
            // 提示成功信息
            this.$message.success('分配权限成功!')
            // 重新请求角色列表数据
            this.getRolesList()
            // 隐藏分配权限对话框
            this.setRightDialogVisible = false
        }
    }
}
</script>

<style lang="less" scoped>
.el-tag {
  margin: 7px;
}
.bd-top {
  border-top: 1px solid #ccc;
}
.bd-bottom {
  border-bottom: 1px solid #ccc;
}
.vcenter {
  display: flex;
  align-items: center;
}
</style>