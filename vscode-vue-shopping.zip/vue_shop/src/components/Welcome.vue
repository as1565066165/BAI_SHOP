<template>
  <div class="container-fluid">
    <!-- 卡片视图区域 -->
    <el-card>
      <!-- 欢迎内容区域 -->
      <div class="jumbotron text-center">
        <h1>One Belt, One Road</h1>
        <p>Welcome to the mall management system!</p>
        <p><a class="btn" role="button" @click="goUserPage">开始</a></p>
      </div>

      <el-divider content-position="left">BAI商城数据统计</el-divider>
      <el-row>
        <!-- 饼状图区域 -->
        <el-col :span="12">
          <!-- 2.为 ECharts 准备一个具备大小（宽高）的 DOM -->
          <div id="main1" style="width: 600px;height:350px;" class="dataChart"></div>
        </el-col>
        <!-- 柱状图区域 -->
        <el-col :span="12">
          <!-- 2.为 ECharts 准备一个具备大小（宽高）的 DOM -->
          <div id="main2" style="width: 600px;height:350px;" class="dataChart"></div>
        </el-col>
      </el-row>

    </el-card>
  </div>
</template>

<script>
import echarts from 'echarts'
export default {
    data () {
        return {
            // 请求参数
            queryInfo: {
                query: '',
                pagenum: 1,
                pagesize: 10
            },
            // 用户列表总数据个数
            usersTotal: '',
            // 权限列表总数据个数
            rightsTotal: '',
            // 角色列表总数据个数
            rolesTotal: '',
            // 分类列表总数据个数
            catesTotal: '',
            // 商品列表总数据个数
            goodsTotal: '',
            // 订单列表总数据个数
            ordersTotal: ''
        }
    },
    created () {
    // 获取用户列表数据
        this.getUsersList()
        // 获取权限列表数据
        this.getRightsList()
        // 获取角色列表数据
        this.getRolesList()
        // 获取分类列表数据
        this.getCatesList()
        // 获取商品列表数据
        this.getGoodsList()
        // 获取订单列表数据
        this.getOrdersList()
    },
    watch: {
        ordersTotal: function () {
            // 基于准备好的dom，初始化echarts实例
            var myChart1 = echarts.init(document.getElementById('main1'))
            var myChart2 = echarts.init(document.getElementById('main2'))
            setTimeout(() => {
                // 指定图表的配置项和数据
                // 饼状图配置项和数据
                var option1 = {
                    title: {
                        text: 'BAI商城数据饼状图',
                        subtext: '服务器中获取',
                        left: 'center'
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: '{a} <br/>{b} : {c} ({d}%)'
                    },
                    legend: {
                        orient: 'vertical',
                        left: 'left',
                        data: ['用户数据', '权限数据', '角色数据', '分类数据', '商品数据', '订单数据']
                    },
                    series: [
                        {
                            name: '访问来源',
                            type: 'pie',
                            radius: '55%',
                            center: ['50%', '60%'],
                            data: [
                                { value: this.usersTotal, name: '用户数据' },
                                { value: this.rightsTotal, name: '权限数据' },
                                { value: this.rolesTotal, name: '角色数据' },
                                { value: this.catesTotal, name: '分类数据' },
                                { value: this.goodsTotal, name: '商品数据' },
                                { value: this.ordersTotal, name: '订单数据' }
                            ],
                            emphasis: {
                                itemStyle: {
                                    shadowBlur: 10,
                                    shadowOffsetX: 0,
                                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                                }
                            }
                        }
                    ]
                }
                // 柱状图配置项和数据
                var option2 = {
                    title: {
                        text: 'BAI商城数据柱状图',
                        subtext: '服务器中获取',
                        left: 'center'
                    },
                    tooltip: {
                        trigger: 'axis',
                        axisPointer: {
                            type: 'cross',
                            crossStyle: {
                                color: '#999'
                            }
                        }
                    },
                    toolbox: {
                        feature: {
                            dataView: { show: true, readOnly: false },
                            magicType: { show: true, type: ['line', 'bar'] },
                            restore: { show: true },
                            saveAsImage: { show: true }
                        }
                    },
                    xAxis: [
                        {
                            type: 'category',
                            data: ['用户数据', '权限数据', '角色数据', '分类数据', '商品数据', '订单数据'],
                            axisPointer: {
                                type: 'shadow'
                            }
                        }
                    ],
                    yAxis: [
                        {
                            type: 'value',
                            name: '数据总数(单位/个)',
                            min: 0,
                            max: 1000,
                            interval: 200,
                            axisLabel: {
                                formatter: '{value} '
                            }
                        }
                    ],
                    series: [
                        {
                            name: '数据',
                            type: 'bar',
                            data: [this.usersTotal,
                                this.rightsTotal,
                                this.rolesTotal,
                                this.catesTotal,
                                this.goodsTotal,
                                this.ordersTotal]
                        }
                    ]
                }
                // 使用刚指定的配置项和数据显示图表。
                myChart1.setOption(option1)
                myChart2.setOption(option2)
            }, 100)
        }
    },
    methods: {
    // 获取用户列表数据
        async getUsersList () {
            // 向服务器发送请求 获取用户列表数据
            const usersRes = await this.$http.get('users', { params: this.queryInfo })
            // 如果请求失败 服务器返回的状态码为200
            if (usersRes.meta.status !== 200) {
                // 提示错误信息 并返回
                return this.$message.error('用户列表数据获取失败!')
            }
            // 将用户列表的总数据个数存储到data中
            this.usersTotal = usersRes.data.total
        },
        // 获取权限列表数据
        async getRightsList () {
            // 向服务器发送请求 获取权限列表数据
            const rightsRes = await this.$http.get('rights/list')
            // 如果请求失败 服务器返回的状态码为200
            if (rightsRes.meta.status !== 200) {
                // 提示错误信息 并返回
                return this.$message.error('权限列表数据获取失败!')
            }
            // 将权限列表的总数据个数存储到data中
            this.rightsTotal = rightsRes.data.length
        },
        // 获取角色列表数据
        async getRolesList () {
            // 向服务器发送请求 获取角色列表数据
            const rolesRes = await this.$http.get('roles')
            // 如果请求失败 服务器返回的状态码为200
            if (rolesRes.meta.status !== 200) {
                // 提示错误信息 并返回
                return this.$message.error('角色列表数据获取失败!')
            }
            // 将角色列表的总数据个数存储到data中
            this.rolesTotal = rolesRes.data.length
        },
        // 获取分类列表数据
        async getCatesList () {
            // 向服务器发送请求 获取分页列表页数据
            const catesRes = await this.$http.get('categories')
            // 如果请求失败 服务器返回的状态码为200
            if (catesRes.meta.status !== 200) {
                // 提示错误信息 并返回
                return this.$message.error('分类列表数据获取失败!')
            }
            // 将分类列表的总数据个数存储到data中
            this.catesTotal = catesRes.data.length
        },
        // 获取商品列表数据
        async getGoodsList () {
            // 向服务器发送请求 获取商品列表页数据
            const goodsRes = await this.$http.get('goods', { params: this.queryInfo })
            // 如果请求失败 返回的状态码不为200
            if (goodsRes.meta.status !== 200) {
                // 提示错误信息并返回
                return this.$message.error('商品列表数据获取失败!')
            }
            // 将商品列表的总数据个数存储到data中
            this.goodsTotal = goodsRes.data.total
        },
        // 获取订单列表数据
        async getOrdersList () {
            // 向服务器发送请求 获取订单列表页面
            const ordersRes = await this.$http.get('orders', { params: this.queryInfo })
            // 如果请求失败 返回的状态码不为200
            if (ordersRes.meta.status !== 200) {
                // 提示错误信息并返回
                return this.$message.error('订单列表数据获取失败!')
            }
            // 将订单列表的总数据个数存储到data中
            this.ordersTotal = ordersRes.data.total
        },
        // 点击开始按钮 跳转到用户列表页面
        goUserPage () {
            this.$router.push('/users')
        }
    }
}
</script>

<style lang="less" scoped>
.container-fluid {
  margin-right: auto;
  margin-left: auto;
  padding-left: 15px;
  padding-right: 15px;
  box-sizing: border-box;
  text-align: center;
  .jumbotron {
    padding: 48px 60px;
    border-radius: 6px;
    margin-bottom: 30px;
    color: inherit;
    background-color: #eeeeee;
    > h1 {
      margin-top: 20px;
      margin-bottom: 10px;
      font-size: 63px;
      font-family: inherit;
      font-weight: 500;
      line-height: 1.1;
    }
    > p {
      margin-bottom: 15px;
      font-size: 21px;
      margin: 0 0 10px;
    }
    .btn {
      display: inline-block;
      margin-bottom: 0;
      font-weight: normal;
      text-align: center;
      vertical-align: middle;
      color: #ffffff;
      background-color: #40586d;
      border-color: #374b5d;
      padding: 10px 16px;
      font-size: 18px;
      line-height: 1.3333333;
      border-radius: 6px;
      touch-action: manipulation;
      cursor: pointer;
      background-image: none;
      border: 1px solid transparent;
      white-space: nowrap;
      user-select: none;
      text-decoration: none;
    }
  }
  .dataChart {
    left: 50%;
    transform: translateX(-50%);
  }
}
</style>