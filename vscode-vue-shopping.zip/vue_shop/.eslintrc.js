module.exports = {
  root: true,

  env: {
    node: true
  },

  extends: ['plugin:vue/essential', '@vue/standard'],

  parserOptions: {
    parser: 'babel-eslint'
  },

  rules: {
    'no-console': 'off',
    'no-debugger': 'off',
    indent: [2, 4],
    'no-spaced-func': 2,
    'no-const-assign': 2,
    'space-before-function-paren': [0, 'always'],
    'eol-last': 0,
    camelcase: 0,
    'no-undef': 0,
    'no-alert': 0,
    'arrow-parens': 0
  },

  extends: ['plugin:vue/essential', '@vue/standard']
}
