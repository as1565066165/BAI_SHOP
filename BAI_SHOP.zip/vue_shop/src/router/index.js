// 导入模块
import Vue from 'vue'
import VueRouter from 'vue-router'
// 懒加载的形式导入路由
const Login = () => import(/* webpackChunkName: "login_home_welcome" */ '../components/Login.vue')
// import Login from '../components/Login.vue'

const Home = () => import(/* webpackChunkName: "login_home_welcome" */ '../components/Home.vue')
// import Home from '../components/Home.vue'

const Welcome = () => import(/* webpackChunkName: "login_home_welcome" */ '../components/Welcome.vue')
// import Welcome from '../components/Welcome.vue'

const Users = () => import(/* webpackChunkName: "users_rights_roles" */ '../components/user/Users.vue')
// import Users from '../components/user/Users.vue'

const Rights = () => import(/* webpackChunkName: "users_rights_roles" */ '../components/power/Rights.vue')
// import Rights from '../components/power/Rights.vue'

const Roles = () => import(/* webpackChunkName: "users_rights_roles" */ '../components/power/Roles.vue')
// import Roles from '../components/power/Roles.vue'

const Params = () => import(/* webpackChunkName: "params_categories" */ '../components/goods/Params.vue')
// import Params from '../components/goods/Params.vue'

const Categories = () => import(/* webpackChunkName: "params_categories" */ '../components/goods/Categories.vue')
// import Categories from '../components/goods/Categories.vue'

const Goods = () => import(/* webpackChunkName: "goods_add_edit" */ '../components/goods/Goods.vue')
// import Goods from '../components/goods/Goods.vue'

const Add = () => import(/* webpackChunkName: "goods_add_edit" */ '../components/goods/Add.vue')
// import Add from '../components/goods/Add.vue'

const Edit = () => import(/* webpackChunkName: "goods_add_edit" */ '../components/goods/Edit.vue')
// import Edit from '../components/goods/Edit.vue'

const Order = () => import(/* webpackChunkName: "order-report" */ '../components/order/Order.vue')
// import Order from '../components/order/Order.vue'
const Report = () => import(/* webpackChunkName: "order-report" */ '../components/report/Report.vue')
// import Report from '../components/report/Report.vue'

// 在router的index.js文件中添加 就不会报Element-UI重复路由的错误
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push (location) {
    return originalPush.call(this, location).catch(err => err)
}

Vue.use(VueRouter)

const router = new VueRouter({
    routes: [
        {
            path: '/',
            redirect: '/login'
        },
        {
            path: '/login',
            component: Login
        },
        {
            path: '/home',
            component: Home,
            redirect: '/welcome',
            children: [
                { path: '/welcome', component: Welcome },
                { path: '/users', component: Users },
                { path: '/rights', component: Rights },
                { path: '/roles', component: Roles },
                { path: '/goods', component: Goods },
                { path: '/params', component: Params },
                { path: '/categories', component: Categories },
                { path: '/goods/add', component: Add },
                { path: '/goods/edit/:id', component: Edit },
                { path: '/orders', component: Order },
                { path: '/reports', component: Report }
            ]
        }
    ]
})

// 挂载路由守卫
router.beforeEach((to, from, next) => {
    // to将要访问的路径
    // from代表从哪个路径跳转而来
    // next是一个函数，表示放行
    // next() 放行  next('/login') 强制跳转
    if (to.path === '/login') return next()
    // 获取token
    const tokenStr = window.sessionStorage.getItem('token')
    if (!tokenStr) return next('/login')
    next()
})

export default router
