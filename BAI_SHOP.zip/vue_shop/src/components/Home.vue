<template>
  <el-container class="home-container">
    <!-- 侧边栏 -->
    <el-aside :width="isCollapse?'64px':'200px'">
      <!-- logo区域 -->
      <div :class="isCollapse?'logo-box hide':'logo-box'">
        <img src="../assets/logo.png" class="avatar">
        <p>BAI商城管理系统</p>
      </div>
      <div :class="isCollapse?'small-logo':'small-logo hide'">
        <img src="../assets/logo.png" alt="">
      </div>
      <!-- 折叠菜单栏按钮 -->
      <div class="toggle-button" @click="toggleCollapse">|||</div>
      <!-- 侧边栏菜单栏区域 -->
      <el-menu :default-active="activePath" class="el-menu-vertical-demo" background-color="#2e4150" text-color="#fff" active-text-color="#409eff" unique-opened :collapse="isCollapse" :collapse-transition="false" :router="true">
        <!-- 一级菜单 -->
        <el-submenu :index="'/'+item.path" v-for="item in menuList" :key="item.id">
          <!-- 一级菜单模板 -->
          <template slot="title">
            <!-- 图标 -->
            <i :class="iconObj[item.id]"></i>
            <!-- 名称 -->
            <span>{{item.authName}}</span>
          </template>

          <!-- 二级菜单 -->
          <el-menu-item :index="'/'+subItem.path" v-for="subItem in item.children" :key="subItem.id">
            <!-- 二级菜单模板 -->
            <template slot="title">
              <!-- 图标 -->
              <i :class="iconObj[subItem.id]"></i>
              <!-- 名称 -->
              <span>{{subItem.authName}}</span>
            </template>
          </el-menu-item>

        </el-submenu>
      </el-menu>
    </el-aside>
    <!-- 页面主体区域 -->
    <el-container>
      <!-- 头部区域 -->
      <el-header>
        <div class="btns">
          <el-button type="info" @click="logout">退出</el-button>
        </div>
      </el-header>
      <!-- 右侧内容主体 -->
      <el-main>
        <!-- 设置路由占位符 -->
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>

</template>

<script>
export default {
    data () {
        return {
            // 左侧菜单数据
            menuList: [],
            // 按钮图标
            iconObj: {
                125: 'iconfont icon-yonghuguanli1',
                110: 'iconfont icon-yonghuliebiao',
                103: 'iconfont icon-quanxian1',
                111: 'iconfont icon-jiaoseguanli1',
                112: 'iconfont icon-cedaohang-quanxian',
                101: 'iconfont icon-shangpinguanli',
                104: 'iconfont icon-shangpinliebiao1',
                115: 'iconfont icon-fenlei',
                121: 'iconfont icon-leimupinleifenleileibie',
                102: 'iconfont icon-dingdanguanli',
                107: 'iconfont icon-dingdanliebiao',
                145: 'iconfont icon-zhandianshujutongji',
                146: 'iconfont icon-shujubaobiao',
                160: 'iconfont icon-yibiaopan',
                161: 'iconfont icon-yibiaopan3'
            },
            // 是否是否水平折叠收起菜单 true折叠 false展开
            isCollapse: false,
            // 菜单按钮的状态值
            activePath: ''
        }
    },
    created () {
    // 获取菜单
        this.getMenuList()
        // 存储获取菜单按钮的状态值
        const activePath = window.sessionStorage.getItem('activePath')
        // 判断菜单按钮的状态值是否已经存在
        if (activePath) {
            this.activePath = activePath
        } else {
            // 如果sessionStorage没有存储菜单按钮的状态值 就默认赋值为/welcome
            this.activePath = '/welcome'
        }
    },
    methods: {
        logout () {
            // 清除token
            window.sessionStorage.clear()
            // 重定向到登录页面
            this.$router.push('/login')
        },
        // 获取菜单按钮
        async getMenuList () {
            const res = await this.$http('menus')
            if (res.meta.status !== 200) return this.$message.error(res.meta.msg)
            this.menuList = res.data
        },
        // 点击按钮缩小、放大菜单栏
        toggleCollapse () {
            this.isCollapse = !this.isCollapse
        }
    },
    // 监听路由
    watch: {
        $route (to, from) {
            // 将跳转的路由地址保存到本地中
            window.sessionStorage.setItem('activePath', to.path)
            // 将跳转的路由地址赋给菜单按钮的状态值
            this.activePath = to.path
        }
    }
}

</script>

<style lang="less" scoped>
.hide {
  display: none;
}
.home-container {
  height: 100%;
}
.el-header {
  background-color: #fff;
  color: #333;
  padding: 10px;
  > div {
    float: right;
    width: 100px;
    height: 100%;
  }
}

.el-aside {
  background-color: #2e4150;
  color: #333;
  .logo-box {
    width: 200px;
    height: 200px;
    padding: 30px;
    text-align: center;
    box-sizing: border-box;
    background-color: #233543;
    .avatar {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      background-color: #eee;
      border: 3px solid rgba(255, 255, 255, 0.3);
      box-shadow: 0 0 20px #fff;
    }
    > p {
      height: 20px;
      font-weight: 700;
      color: #a9b0c2;
    }
  }
  .small-logo {
    width: 64px;
    height: 64px;
    padding: 7px;
    box-sizing: border-box;
    > img {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      background-color: #eee;
      border: 1px solid rgba(255, 255, 255, 0.3);
      box-shadow: 0 0 8px #fff;
    }
  }
  .toggle-button {
    width: 100%;
    height: 24px;
    line-height: 24px;
    background-color: #ddd;
    color: #fff;
    font-size: 10px;
    text-align: center;
    letter-spacing: 0.2em;
    cursor: pointer;
  }
  .toggle-button:hover {
    color: #409eff;
  }
  .el-menu {
    border-right: 0;
    .iconfont {
      margin: 0 10px 0 8px;
    }
  }
}

.el-main {
  background-color: #f8f9fb;
  color: #333;
}
</style>
