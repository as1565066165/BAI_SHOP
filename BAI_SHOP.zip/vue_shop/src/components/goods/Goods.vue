<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>商品管理</el-breadcrumb-item>
      <el-breadcrumb-item>商品列表</el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 卡片视图区域 -->
    <el-card>
      <el-row :gutter="20">
        <el-col :span="8">
          <el-input placeholder="请输入内容" v-model="queryInfo.query" clearable @change="getGoodsList" @clear="getGoodsList">
            <el-button slot="append" icon="el-icon-search" @click="getGoodsList"></el-button>
          </el-input>
        </el-col>
        <el-col :span="4">
          <el-button type="primary" @click="goAddPage">添加商品</el-button>
        </el-col>
      </el-row>
      <!-- table表格区域 -->
      <el-table :data="goodslist" border stripe>
        <!-- 索引列 -->
        <el-table-column label="#" type="index"></el-table-column>
        <el-table-column label="商品名称" prop="goods_name"></el-table-column>
        <el-table-column label="商品价格(元)" prop="goods_price" width="90px"></el-table-column>
        <el-table-column label="商品重量" prop="goods_weight" width="70px"></el-table-column>
        <el-table-column label="创建时间" prop="add_time" width="140px">
          <template v-slot="{row}">
            {{row.add_time|dateFormat('yyyy-MM-dd hh:mm:ss')}}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="130px">
          <template v-slot="{row}">
            <!-- 修改按钮 -->
            <el-tooltip effect="dark" content="编辑" placement="top" :enterable="false">
              <el-button type="primary" icon="el-icon-edit" size="mini" @click="showEditDialog(row.goods_id)"></el-button>
            </el-tooltip>
            <!-- 删除按钮 -->
            <el-tooltip effect="dark" content="删除" placement="top" :enterable="false">
              <el-button type="danger" icon="el-icon-delete" size="mini" @click="deleteGoodsInfo(row.goods_id)"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页区域 -->
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="queryInfo.pagenum" :page-sizes="[5, 10, 20, 30]" :page-size="queryInfo.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="total">
      </el-pagination>
    </el-card>
  </div>
</template>

<script>
export default {
    data () {
        return {
            // 查询参数对象
            queryInfo: {
                query: '',
                pagenum: 1,
                pagesize: 10
            },
            // 保存商品列表数据
            goodslist: [],
            // 商品数据条数
            total: 0
        }
    },
    created () {
        this.getGoodsList()
    },
    methods: {
    // 根据分页获取商品列表数据
        async getGoodsList () {
            // 向服务器发送请求 获取商品列表数据
            const res = await this.$http.get('goods', { params: this.queryInfo })
            if (res.meta.status !== 200) {
                return this.$message.error('商品列表数据获取失败!')
            }
            // 将查询出来的商品列表数据存储到data中
            this.goodslist = res.data.goods
            // 将查询的数据的个数存储到data中
            this.total = res.data.total
        },
        // 当商品每页显示数据个数发生改变时 触发函数
        handleSizeChange (newSize) {
            // 将查询每页数据的个数赋值为新的查询个数
            this.queryInfo.pagesize = newSize
            // 重新获取商品列表页数据
            this.getGoodsList()
        },
        // 当当前页发生改变时 触发函数
        handleCurrentChange (newPage) {
            // 将当前页赋值为最新的页数
            this.queryInfo.pagenum = newPage
            // 重新获取商品列表页数据
            this.getGoodsList()
        },
        // 点击按钮去往添加商品页面
        goAddPage () {
            this.$router.push('/goods/add')
        },
        // 点击编辑按钮 编辑商品信息
        showEditDialog (id) {
            this.$router.push(`/goods/edit/${id}`)
        },
        // 点击删除按钮 删除商品信息
        deleteGoodsInfo (id) {
            // 弹出确认提示框防止用户误触删除按钮
            this.$confirm('此操作将永久删除该商品信息, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(async () => {
                // 向服务器发送请求 删除商品信息
                const res = await this.$http.delete(`goods/${id}`)
                if (res.meta.status !== 200) {
                    return this.$message.error('商品信息删除失败！')
                }
                // 重新获取商品列表信息
                this.getGoodsList()
                this.$message.success('商品信息删除成功!')
            }).catch(() => {
                this.$message.info('已取消删除!')
            })
        }
    }
}
</script>

<style lang="less" scoped>
</style>