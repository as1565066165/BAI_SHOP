<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>商品管理</el-breadcrumb-item>
      <el-breadcrumb-item>商品分类</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 卡片视图区域 -->
    <el-card>
      <!-- 按钮区域 -->
      <el-row>
        <el-col>
          <el-button type="primary" @click="showAddCateDialog">添加分类</el-button>
        </el-col>
      </el-row>
      <!-- 表格区域 -->
      <tree-table :tree-type="true" class="treeTable" :data='catelist' :columns="columns" :selection-type="false" :expand-type="false" show-index index-text="#" border>
        <!-- 是否有效 -->
        <template v-slot:isok="{row}">
          <i class="el-icon-success successColor" v-if="row.cat_deleted===false"></i>
          <i class="el-icon-error errorColor" v-else></i>
        </template>
        <!-- 排序 -->
        <template v-slot:order="{row}">
          <el-tag v-if="row.cat_level===0" size="small">一级</el-tag>
          <el-tag type="success" v-else-if="row.cat_level===1" size="small">二级</el-tag>
          <el-tag type="warning" v-else size="small">三级</el-tag>
        </template>
        <!-- 操作 -->
        <template v-slot:opt="{row}">
          <el-button type="primary" icon="el-icon-edit" size="mini" @click="showEditDialog(row.cat_id)">编辑</el-button>
          <el-button type="danger" icon="el-icon-delete" size="mini" @click="deleteCateInfo(row.cat_id)">删除</el-button>
        </template>
      </tree-table>
      <!-- 分页区域 -->
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="queryInfo.pagenum" :page-sizes="[3, 5, 10, 15]" :page-size="queryInfo.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="total">
      </el-pagination>
    </el-card>

    <!-- 添加分类对话框 -->
    <el-dialog title="添加分类" :visible.sync="addDialogVisible" width="50%" @close="addCateDialogClosed">
      <el-form :model="addCateForm" :rules="addCateFormRules" ref="addCateFormRef" label-width="100px" status-icon>
        <el-form-item label="分类名称" prop="cat_name">
          <el-input v-model="addCateForm.cat_name"></el-input>
        </el-form-item>
        <el-form-item label="父级分类">
          <el-cascader v-model="selectKeys" :options="parentCateList" :props="cascaderProps" @change="parentCateChange" clearable></el-cascader>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="addDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="addCate">添 加</el-button>
      </span>
    </el-dialog>

    <!-- 编辑分类对话框 -->
    <el-dialog title="编辑分类" :visible.sync="editDialogVisible" width="50%" @close="editCateDialogClosed">
      <el-form :model="editCateForm" :rules="addCateFormRules" ref="editCateFormRef" label-width="100px" status-icon>
        <el-form-item label="分类名称" prop="cat_name">
          <el-input v-model="editCateForm.cat_name"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="editDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="editCate">提 交</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
    data () {
        return {
            // 查询参数
            queryInfo: {
                type: 3,
                pagenum: 1,
                pagesize: 5
            },
            // 商品分类的数据列表 默认为空
            catelist: [],
            // 父级分类的数据列表
            parentCateList: [],
            // 商品分类总数
            total: 0,
            columns: [
                {
                    label: '分类名称',
                    prop: 'cat_name'
                },
                {
                    label: '是否有效',
                    // 表示将当前页定义为模板列
                    type: 'template',
                    // 表示模板的名称
                    template: 'isok'
                },
                {
                    label: '排序',
                    // 表示将当前页定义为模板列
                    type: 'template',
                    // 表示模板的名称
                    template: 'order'
                },
                {
                    label: '操作',
                    // 表示将当前页定义为模板列
                    type: 'template',
                    // 表示模板的名称
                    template: 'opt'
                }
            ],
            // 显示 / 隐藏 添加分类对话框
            addDialogVisible: false,
            // 显示 / 隐藏 编辑分类对话框
            editDialogVisible: false,
            // 添加分类的表单
            addCateForm: {
                // 分类名称
                cat_name: '',
                // 分类父 ID
                cat_pid: 0,
                // 分类层级,默认为一级分类
                cat_level: 0
            },
            // 编辑分类表单
            editCateForm: {},
            // 添加分类表单的验证规则
            addCateFormRules: {
                // 分类名称验证规则
                cat_name: [
                    { required: true, message: '请输入分类名称', trigger: 'blur' }
                ]
            },
            // 指定联级选择器的配置对象
            cascaderProps: {
                expandTrigger: 'hover',
                label: 'cat_name',
                value: 'cat_id',
                children: 'children',
                checkStrictly: true
            },
            // 选中的父级分类的id数组
            selectKeys: []

        }
    },
    created () {
        this.getCateList()
    },
    methods: {
    // 获取商品分类数据
        async getCateList () {
            //  向服务器发送请求 获取商品分类数据
            const res = await this.$http.get('categories', { params: this.queryInfo })
            if (res.meta.status !== 200) {
                return this.$message.error('获取商品分类数据失败!')
            }
            // 把数据列表赋值给catelist
            this.catelist = res.data.result
            // 为总数据条数赋值
            this.total = res.data.total
        },
        // 监听pagesize改变的事件
        handleSizeChange (newSize) {
            this.queryInfo.pagesize = newSize
            this.getCateList()
        },
        // 监听当前页发生改变的事件
        handleCurrentChange (newPage) {
            this.queryInfo.pagenum = newPage
            this.getCateList()
        },
        // 点击添加分类按钮 显示对话框
        showAddCateDialog () {
            // 获取父类分类数据列表
            this.getParentCateList()
            this.addDialogVisible = true
        },
        // 获取父类分类数据列表
        async getParentCateList () {
            const res = await this.$http.get('categories', { params: { type: 2 } })
            if (res.meta.status !== 200) {
                return this.$message.error('父级分类列表获取失败!')
            }
            this.parentCateList = res.data
        },
        // 选择项发生变化触发这个函数
        parentCateChange () {
            // 判断是否选中了父级分类 有没有父级id值
            if (this.selectKeys.length > 0) {
                // 赋值父级id 数组的最后一项才是亲爸爸
                this.addCateForm.cat_pid = this.selectKeys[this.selectKeys.length - 1]
                // 分类的等级正好是父级id数组的长度
                this.addCateForm.cat_level = this.selectKeys.length
            } else {
                // 如果没有选中 就赋值为根分类
                this.addCateForm.cat_pid = 0
                this.addCateForm.cat_level = 0
            }
        },
        // 当添加分类对话框关闭时触发
        addCateDialogClosed () {
            // 清空表单数据
            this.$refs.addCateFormRef.resetFields()
            this.selectKeys = []
            this.addCateForm.cat_pid = 0
            this.addCateForm.cat_level = 0
        },
        // 点击按钮添加新的分类
        addCate () {
            // 验证表单数据
            this.$refs.addCateFormRef.validate(async valid => {
                if (!valid) {
                    // 如果数据格式不符合验证规则 返回并提示错误信息
                    return this.$message.error('请输入正确的分类信息!')
                }
                // 向服务器发送请求 添加分类信息
                const res = await this.$http.post('categories', this.addCateForm)
                if (res.meta.status !== 201) {
                    return this.$message.error('添加分类失败!')
                }
                // 提示成功信息
                this.$message.success('添加分类成功!')
                // 重新获取分类列表数据
                this.getCateList()
                // 关闭添加分类对话框
                this.addDialogVisible = false
            })
        },
        // 当点击了编辑按钮 显示编辑分类对话框
        async showEditDialog (id) {
            // 向服务器发送请求 根据id查询分类
            const res = await this.$http.get(`categories/${id}`)
            if (res.meta.status !== 200) {
                return this.$message.error('分类信息获取失败!')
            }
            this.editCateForm = res.data
            this.editDialogVisible = true
        },
        // 当点击了提交按钮时 修改分类信息
        async editCate () {
            // 获取修改分类的id
            const id = this.editCateForm.cat_id
            // 获取修改后的分类名称
            const cat_name = this.editCateForm.cat_name
            // 向服务器发送请求 编辑分类信息
            const res = await this.$http.put(`categories/${id}`, { cat_name })
            // 如果请求失败
            if (res.meta.status !== 200) {
                // 提示失败信息 并返回
                return this.$message.error('修改分类失败!')
            }
            // 提示成功信息
            this.$message.success('修改分类成功!')
            // 重新获取分类列表数据
            this.getCateList()
            // 关闭修改分类对话框
            this.editDialogVisible = false
        },
        // 当编辑对话框关闭的时候 清除对话框表单
        editCateDialogClosed () {
            this.$refs.editCateFormRef.resetFields()
        },
        deleteCateInfo (id) {
            // 弹出确认提示框防止用户误触删除按钮
            this.$confirm('此操作将永久删除该分类信息, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(async () => {
                // 向服务器发送请求 删除分类信息
                const res = await this.$http.delete(`categories/${id}`)
                if (res.meta.status !== 200) {
                    return this.$message.error('分类信息删除失败！')
                }
                // 重新获取分类列表信息
                this.getCateList()
                this.$message.success('分类信息删除成功!')
            }).catch(() => {
                this.$message.info('已取消删除!')
            })
        }
    }
}
</script>

<style lang="less" scoped>
.successColor {
  color: #85cb62;
}
.errorColor {
  color: #f86968;
}
.treeTable {
  margin-top: 15px;
}
.el-cascader {
  width: 100%;
}
</style>