<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>订单管理</el-breadcrumb-item>
      <el-breadcrumb-item>订单列表</el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 卡片视图区域 -->
    <el-card>
      <!-- 添加搜索区域 -->
      <el-row>
        <el-col :span="8">
          <div>
            <el-input placeholder="请输入内容" v-model="queryInfo.query" @change="getOrderList">
              <el-button slot="append" icon="el-icon-search" @click="getOrderList"></el-button>
            </el-input>
          </div>
        </el-col>
      </el-row>
      <!-- 表格内容区域 -->
      <el-table :data="orderlist" border stripe>
        <!-- 索引列 -->
        <el-table-column label="#" type="index"></el-table-column>
        <!-- 内容页 -->
        <el-table-column label="订单编号" prop="order_number"></el-table-column>
        <el-table-column label="发票内容" prop="order_fapiao_content" width="120px"></el-table-column>
        <el-table-column label="购买单位" prop="order_fapiao_title" width="120px">
          <template v-slot="{row}">
            <el-tag v-if="row.order_fapiao_title==='个人'" class="iconfont icon-webicon08 ">个人</el-tag>
            <el-tag type="success" v-else class="iconfont icon-gongsi4">公司</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="订单价格" prop="order_price" width="100px"></el-table-column>
        <el-table-column label="是否付款" prop="pay_status" width="120px">
          <template v-slot="{row}">
            <el-tag type="danger" v-if="row.pay_status==='0'">未付款</el-tag>
            <el-tag type="success" v-else>已付款</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="是否发货" prop="is_send" width="80px"></el-table-column>
        <el-table-column label="下单时间" width="180px">
          <template v-slot="{row}">
            {{row.create_time|dateFormat('yyyy-MM-dd hh:mm:ss')}}
          </template>
        </el-table-column>
        <!-- 操作列 -->
        <el-table-column label="操作" width="180px">
          <template>
            <!-- 修改地址按钮 -->
            <el-tooltip effect="dark" content="修改地址" placement="top">
              <el-button type="primary" icon="iconfont icon-changeAddress" size="mini" @click="showAddressDialog"></el-button>
            </el-tooltip>
            <!-- 物流信息按钮 -->
            <el-tooltip effect="dark" content="物流信息" placement="top">
              <el-button type="success" icon="iconfont icon-wuliuxinxi" size="mini" @click="showProgressBox"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="queryInfo.pagenum" :page-sizes="[5, 10, 15, 30]" :page-size="queryInfo.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="total">
      </el-pagination>
    </el-card>
    <!-- 修改地址对话框 -->
    <el-dialog title="修改地址" :visible.sync="editAddressDialogVisible" width="50%" @close="editAddressDialogClosed">
      <!-- 修改表单区域 -->
      <el-form :model="editAddressForm" :rules="editAddressFormRules" ref="editAddressFormRef" label-width="100px">
        <el-form-item label="省市区/县" prop="location">
          <el-cascader v-model="editAddressForm.location" :options="cityData" :props="locationProps" @change="handleChange"></el-cascader>
        </el-form-item>
        <el-form-item label="详细地址" prop="detailedAddress">
          <el-input v-model="editAddressForm.detailedAddress"></el-input>
        </el-form-item>
      </el-form>
      <!-- 底部按钮区域 -->
      <span slot="footer" class="dialog-footer">
        <el-button @click="editAddressDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="editAddress">提 交</el-button>
      </span>
    </el-dialog>

    <!-- 物流进度对话框 -->
    <el-dialog title="物流进度" :visible.sync="progressDialogVisible" width="50%">
      <!-- 时间线 -->
      <el-timeline>
        <el-timeline-item v-for="(activity, index) in progressData" :key="index" :timestamp="activity.time">
          {{activity.context}}
        </el-timeline-item>
      </el-timeline>
    </el-dialog>
  </div>
</template>

<script>
import cityData from '../../tools/citydata.js'
export default {
    data () {
        return {
            //  请求参数
            queryInfo: {
                query: '',
                pagenum: 1,
                pagesize: 5
            },
            // 订单列表数据
            orderlist: [],
            // 订单列表数据条数
            total: 0,
            // 显示 / 隐藏 修改地址对话框
            editAddressDialogVisible: false,
            // 显示 / 隐藏 物流进度对话框
            progressDialogVisible: false,
            // 修改地址表单数据
            editAddressForm: {
                detailedAddress: '',
                location: []
            },
            // 修改地址表单验证规则
            editAddressFormRules: {
                // 详细地址
                detailedAddress: [
                    { required: true, message: '请输入详细地址', trigger: 'blur' }
                ],
                // 省市区/县地址
                location: [
                    {
                        required: true,
                        message: '请选择省市区/县'
                    }
                ]
            },
            // 城市数据
            cityData,
            // 级联框配置参数
            locationProps: {
                expandTrigger: 'hover',
                label: 'label',
                value: 'value',
                children: 'children'
            },
            // 物流信息
            progressData: []

        }
    },
    created () {
    // 获取订单列表数据
        this.getOrderList()
    },
    methods: {
    // 获取订单列表数据
        async getOrderList () {
            // 向服务器发送请求 获取订单数据列表
            const res = await this.$http.get('orders', { params: this.queryInfo })
            // 如果服务器请求失败 状态码不为200
            if (res.meta.status !== 200) {
                // 返回并提示错误信息
                return this.$message.error('订单列表获取失败!')
            }
            // 将订单列表数据存储到data中
            this.orderlist = res.data.goods
            // 存储订单数据列表个数
            this.total = res.data.total
        },
        // 当分页数据个数发生改变时 调用函数
        handleSizeChange (newSize) {
            this.queryInfo.pagesize = newSize
            this.getOrderList()
        },
        // 当当前页数发生改变时 调用函数
        handleCurrentChange (newPage) {
            this.queryInfo.pagenum = newPage
            this.getOrderList()
        },
        // 点击修改地址按钮 修改地址
        showAddressDialog () {
            this.editAddressDialogVisible = true
        },
        // 级联选择框选项发生变化 调用函数
        handleChange () {

        },
        // 编辑对话框关闭时 调用函数
        editAddressDialogClosed () {
            // 清空表单内容
            this.editAddressForm.location = []
            this.$refs.editAddressFormRef.resetFields()
        },
        // 点击提交按钮 修改地址
        editAddress () {
            // 表单校验
            this.$refs.editAddressFormRef.validate(valid => {
                if (!valid) {
                    // 校验失败 提示错误信息并返回
                    return this.$message.error('请输入正确的地址信息!')
                }
                // 提示成功信息
                this.$message.success('修改地址信息成功!')
                // 重新获取订单列表数据
                this.getOrderList()
                // 关闭修改地址对话框
                this.editAddressDialogVisible = false
            })
        },
        // 点击物流信息按钮 显示物流信息
        async showProgressBox () {
            const res = await this.$http.get('/kuaidi/1106975712662')
            if (res.meta.status !== 200) {
                return this.$message.error('获取物流信息失败!')
            }
            this.progressData = res.data
            this.$message.success('获取物流信息成功!')
            this.progressDialogVisible = true
        }
    }
}
</script>

<style lang="less" scoped>
.iconfont {
  font-size: 12px;
}
</style>