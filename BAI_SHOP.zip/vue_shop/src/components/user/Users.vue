<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>用户管理</el-breadcrumb-item>
      <el-breadcrumb-item>用户列表</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 卡片视图区域 -->
    <el-card>
      <!-- 添加搜索区域 -->
      <el-row :gutter="20">
        <el-col :span="8">
          <div>
            <el-input placeholder="请输入内容" v-model="queryInfo.query" @change="getUserList" clearable>
              <el-button slot="append" icon="el-icon-search" @click="getUserList"></el-button>
            </el-input>
          </div>
        </el-col>
        <el-col :span="2">
          <div>
            <el-button type="primary" @click="addDialogVisible=true">添加用户</el-button>
          </div>
        </el-col>
      </el-row>

      <!-- 用户列表区域 -->
      <el-table :data="userList" border style="width: 100%" :stripe="true">
        <el-table-column type="index" label="#"> </el-table-column>
        <el-table-column prop="username" label="姓名"> </el-table-column>
        <el-table-column prop="email" label="邮箱"> </el-table-column>
        <el-table-column prop="mobile" label="电话"> </el-table-column>
        <el-table-column prop="role_name" label="角色"> </el-table-column>
        <el-table-column label="状态">
          <template v-slot="{row}">
            <el-switch v-model="row.mg_state" @change="userStateChange(row)">
            </el-switch>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template v-slot="{row}">
            <!-- 修改按钮 -->
            <el-tooltip effect="dark" content="编辑" placement="top" :enterable="false">
              <el-button type="primary" icon="el-icon-edit" size="mini" @click="showEditDialog(row.id)"></el-button>
            </el-tooltip>
            <!-- 删除按钮 -->
            <el-tooltip effect="dark" content="删除" placement="top" :enterable="false">
              <el-button type="danger" icon="el-icon-delete" size="mini" @click="deleteUserInfo(row.id)"></el-button>
            </el-tooltip>
            <!-- 分配角色按钮 -->
            <el-tooltip effect="dark" content="分配角色" placement="top" :enterable="false">
              <el-button type="warning" icon="el-icon-setting" size="mini" @click="showSetRoleDialog(row)"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页区域 -->
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="queryInfo.pagenum" :page-sizes="[1, 2, 5, 10]" :page-size="queryInfo.pagesize" layout="total, sizes, prev, pager, next, jumper" :total="total">
      </el-pagination>
    </el-card>

    <!-- 添加用户的对话框 -->
    <el-dialog title="添加用户" :visible.sync="addDialogVisible" width="50%" @close="addDialogClosed">
      <!-- 内容主体区域 -->
      <el-form :model="addForm" :rules="addFormRules" ref="addFormRef" label-width="80px" :status-icon="true">
        <!-- 用户名输入框 -->
        <el-form-item label="用户名" prop="username">
          <el-input v-model="addForm.username"></el-input>
        </el-form-item>
        <!-- 密码输入框 -->
        <el-form-item label="密码" prop="password">
          <el-input v-model="addForm.password" type="password"></el-input>
        </el-form-item>

        <!-- 密码确认提示框 -->
        <el-form-item label="确认密码" prop="confirmPwd">
          <el-input type="password" v-model="cPwd"></el-input>
        </el-form-item>

        <!-- 邮箱输入框 -->
        <el-form-item label="邮箱地址" prop="email">
          <el-input v-model="addForm.email"></el-input>
        </el-form-item>
        <!-- 手机号码输入框 -->
        <el-form-item label="手机号码" prop="mobile">
          <el-input v-model="addForm.mobile"></el-input>
        </el-form-item>
      </el-form>
      <!-- 底部区域 -->
      <span slot="footer" class="dialog-footer">
        <el-button @click="addDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="addUser">添 加</el-button>
      </span>
    </el-dialog>

    <!-- 编辑用户信息的对话框 -->
    <el-dialog title="编辑用户信息" :visible.sync="editDialogVisible" width="50%" @close="editDialogClosed">
      <!-- 编辑用户信息主体 -->
      <el-form :model="editForm" :rules="editFormRules" ref="editFormRef" label-width="80px" :status-icon="true">
        <el-form-item label="用户名">
          <el-input v-model="editForm.username" disabled></el-input>
        </el-form-item>
        <el-form-item label="邮箱地址" prop="email">
          <el-input v-model="editForm.email"></el-input>
        </el-form-item>
        <el-form-item label="手机号码" prop="mobile">
          <el-input v-model="editForm.mobile"></el-input>
        </el-form-item>
      </el-form>
      <!-- 底部区域 -->
      <span slot="footer" class="dialog-footer">
        <el-button @click="editDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="editUserInfo">提 交</el-button>
      </span>
    </el-dialog>

    <!-- 分配角色对话框 -->
    <el-dialog title="分配角色" :visible.sync="setRoleDialogVisible" width="50%" @close="setRoleDialogClosed">
      <div>
        <p>当前的用户: {{userInfo.username}}</p>
        <p>当前的角色: {{userInfo.role_name}}</p>
        <p>分配新角色:
          <el-select v-model="selectRoleId" placeholder="请选择">
            <el-option v-for="item in rolesList" :key="item.id" :label="item.roleName" :value="item.id">
            </el-option>
          </el-select>
        </p>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="setRoleDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveRoleInfo">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
    data () {
    // 自定义邮箱验证规则
        var checkEmail = (rule, value, cb) => {
            // 邮箱的正则表达式
            const emailReg = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
            // 验证输入数据
            if (emailReg.test(value)) {
                return cb()
            }
            cb(new Error('请输入正确的邮箱地址'))
        }
        // 自定义手机号码验证规则
        var checkMobile = (rule, value, cb) => {
            // 邮箱的正则表达式
            const mobileReg = /^(13[0-9]|14[5|7]|15[0|1|2|3|4|5|6|7|8|9]|18[0|1|2|3|5|6|7|8|9])\d{8}$/
            if (mobileReg.test(value)) {
                return cb()
            }
            cb(new Error('请输入正确的手机号码'))
        }
        // 确认密码验证规则
        var checkPwd = (rule, value, cb) => {
            if (this.cPwd === '') {
                cb(new Error('请再次输入密码'))
            } else if (this.cPwd !== this.addForm.password) {
                cb(new Error('两次输入密码不一致!'))
            } else {
                cb()
            }
        }
        return {
            queryInfo: {
                // 查询参数
                query: '',
                // 当前页码
                pagenum: 1,
                // 每页显示多少条数据
                pagesize: 2
            },
            userList: [],
            total: 0,
            // 控制添加用户对话框的显示与隐藏
            addDialogVisible: false,
            // 控制编辑用户对话框的显示与隐藏
            editDialogVisible: false,
            // 控制分配角色对话框的显示与隐藏
            setRoleDialogVisible: false,
            // 验证密码
            cPwd: '',
            // 添加表单
            addForm: {
                username: '',
                password: '',
                email: '',
                mobile: ''
            },
            editForm: {},
            // 添加表单验证规则
            addFormRules: {
                // 用户名验证规则
                username: [
                    { required: true, message: '请输入用户名称', trigger: 'blur' },
                    { min: 3, max: 15, message: '长度在 3 到 15 个字符', trigger: 'blur' }
                ],
                // 密码验证规则
                password: [
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { min: 6, max: 20, message: '长度在 6 到 20 个字符', trigger: 'blur' }
                ],
                // 确认密码验证规则
                confirmPwd: [
                    { validator: checkPwd, required: true, trigger: 'blur' }
                ],
                // 邮箱地址验证规则
                email: [
                    { required: true, message: '请输入邮箱地址', trigger: 'blur' },
                    { validator: checkEmail, trigger: 'blur' }
                ],
                // 手机号码验证规则
                mobile: [
                    { required: true, message: '请输入手机号码', trigger: 'blur' },
                    { validator: checkMobile, trigger: 'blur' }
                ]
            },
            // 编辑表单验证规则
            editFormRules: {
                // 邮箱地址验证规则
                email: [
                    { required: true, message: '请输入邮箱地址', trigger: 'blur' },
                    { validator: checkEmail, trigger: 'blur' }
                ],
                // 手机号码验证规则
                mobile: [
                    { required: true, message: '请输入手机号码', trigger: 'blur' },
                    { validator: checkMobile, trigger: 'blur' }
                ]
            },
            // 需要被分配角色的用户信息
            userInfo: {},
            // 角色列表数据
            rolesList: [],
            // 选择的角色id
            selectRoleId: ''
        }
    },
    created () {
        this.getUserList()
    },
    methods: {
    // 获取用户列表
        async getUserList () {
            const res = await this.$http.get('users', { params: this.queryInfo })
            if (res.meta.status !== 200) {
                return this.$message.error('获取用户信息失败：' + res.meta.msg)
            }
            this.userList = res.data.users
            this.total = res.data.total
        },
        // 当每页显示数据发送改变时 触发函数
        handleSizeChange (newSize) {
            this.queryInfo.pagesize = newSize
            this.getUserList()
        },
        // 当页码发生改变时 触发函数
        handleCurrentChange (newPage) {
            this.queryInfo.pagenum = newPage
            this.getUserList()
        },
        // 当用户状态发生改变时 触发函数
        async userStateChange (user) {
            const res = await this.$http.put(`users/${user.id}/state/${user.mg_state}`)
            // 如果服务器返回的状态码不为200————用户信息修改失败
            if (res.meta.status !== 200) {
                // 将页面修改的状态还原
                user.mg_state = !user.mg_state
                // 提示操作错误信息
                return this.$message.error('用户信息修改失败!')
            }
            // 提示操作成功信息
            this.$message.success('用户信息修改成功！')
        },
        // 当对话框关闭时 触发函数
        addDialogClosed () {
            // 清除确认密码框的内容
            this.cPwd = ''
            // 清除其余的表单内容
            this.$refs.addFormRef.resetFields()
        },
        // 点击按钮 添加用户
        addUser () {
            this.$refs.addFormRef.validate(async valid => {
                // 检测校验信息
                if (!valid) { return this.$message.error('请填写符合要求用户信息') }
                // 向服务器发送请求 创建用户
                const res = await this.$http.post('users', this.addForm)
                // 如果返回的状态码不为201 表示用户创建失败
                if (res.meta.status !== 201) {
                    // 抛出提示信息 并返回
                    return this.$message.error('用户创建失败！')
                }
                // 提示信息——用户创建成功
                this.$message.success('用户创建成功')
                // 隐藏对话框
                this.addDialogVisible = false
                // 重新获取用户列表数据
                this.getUserList()
            })
        },
        // 显示编辑用户信息的对话框
        async showEditDialog (id) {
            const res = await this.$http.get(`users/${id}`)
            if (res.meta.status !== 200) {
                return this.$message.error('查询用户信息失败')
            }
            // 将查询的结果 赋值给修改表单
            this.editForm = res.data
            this.editDialogVisible = true
        },
        // 当修改输入框关闭时触发
        editDialogClosed () {
            // 清除修改表单的内容和校验信息
            this.$refs.editFormRef.resetFields()
        },
        // 当点击了编辑表单的提交按钮触发
        editUserInfo () {
            // 修改表单提交时的预验证
            this.$refs.editFormRef.validate(async valid => {
                if (!valid) {
                    return this.$message.error('请填写正确的用户信息!')
                }
                // 向服务器发送请求 修改用户信息
                const res = await this.$http.put(`users/${this.editForm.id}`, {
                    email: this.editForm.email,
                    mobile: this.editForm.mobile
                })
                // 如果返回的状态码不为200 修改失败
                if (res.meta.status !== 200) {
                    return this.$message.error('用户信息修改失败!')
                }
                // 关闭修改对话框
                this.editDialogVisible = false
                // 重新请求用户列表数据
                this.getUserList()
                // 提示信息 修改用户信息成功
                this.$message.success('用户信息修改成功!')
            })
        },
        // 当点击了表格的删除按钮触发
        deleteUserInfo (id) {
            // 弹出确认提示框防止用户误触删除按钮
            this.$confirm('此操作将永久删除该用户信息, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(async () => {
                // 向服务器发送请求 删除用户信息
                const res = await this.$http.delete(`users/${id}`)
                if (res.meta.status !== 200) {
                    return this.$message.error('用户信息删除失败！')
                }
                // 重新获取用户列表信息
                this.getUserList()
                this.$message.success('用户信息删除成功!')
            }).catch(() => {
                this.$message.info('已取消删除!')
            })
        },
        // 当点击了分配角色按钮 展示分配角色的对话框
        async showSetRoleDialog (userInfo) {
            // 将用户数据保存到data中
            this.userInfo = userInfo
            // 向服务器发送请求 获取角色列表
            const res = await this.$http.get('roles')
            // 如果请求失败
            if (res.meta.status !== 200) {
                // 提示失败信息并返回
                return this.$message.error('角色列表获取失败!')
            }
            // 将角色列表数据保存到data中
            this.rolesList = res.data
            // 显示分配角色的对话框
            this.setRoleDialogVisible = true
        },
        // 点击按钮分配角色
        async saveRoleInfo () {
            // 如果用户没有选择角色
            if (!this.selectRoleId) {
                return this.$message.error('请选择要分配的角色!')
            }
            // 向服务器发送请求 分配角色
            const res = await this.$http.put(`users/${this.userInfo.id}/role`, { rid: this.selectRoleId })
            // 如果请求失败
            if (res.meta.status !== 200) {
                // 提示失败信息并返回
                return this.$message.error('设置角色失败!')
            }
            // 提示成功信息
            this.$message.success('设置角色成功!')
            // 重新请求用户数据
            this.getUserList()
            // 关闭设置角色信息对话框
            this.setRoleDialogVisible = false
        },
        // 当设置角色对话框关闭时
        setRoleDialogClosed () {
            this.userInfo = ''
            this.selectRoleId = ''
        }
    }
}
</script>

<style lang="less" scoped></style>
